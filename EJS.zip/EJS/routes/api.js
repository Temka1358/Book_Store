const express = require("express");
const req = require("express/lib/request");
const { get } = require("express/lib/response");
const fs = require('fs')
const app  = express()
const router = express.Router()

//Middleware
router.get('/user/:id', (req, res, next)=>{
    const user_id = req.params.id;
    //3
    if(user_id == 0){
        return res.status(500).json({"message": "User id with 0 is error"})
    }
    //1
    // if(user_id < 0 ){
    //     const err = new Error("Can\'t find user with this ID");
    //     err.status = "fail";
    //     err.statusCode = 501;
    //     return next(err)
    // }
    //2
    if(user_id < 10 ){
        const err = new Error("Cant find user with this ID");
        err.status = "fail";
        err.statusCode = 500;
        return next(err)
    }
    //4
    if(user_id> 100){
        const err = new Error("Can't find user with this ID!(version4)")
        err.status = "fail";
        err.statusCode = 500;
        return next(err);
    }

        res.send("User Info with ID "+ user_id);
                // if(user_id % 2 === 0) next('route'); 
                // if (user_id < 50) next ();
                // date = new Date(Date.now());
                // fs.appendFile("user_activity_log.json", "\nUserID: " + req.params.id + " Date: " + date.toString(), ()=>{})
                // res.send("I will send user information #1 ID is odd")
}, function(err ,req, res, next){
    console.log("Funciton error called")
    res.status(500).json({"messageeee": err.status})
    // res.send("I will send user information #1.1")
})

// function logOriginalUrl(req, res, next){
//     console.log("Request URL:" , req.originalUrl);
//     date = new Date(Date.now());
//     fs.appendFile("user_activity_log.json", "\nUserID: " + req.params.id + " Date: " + date.toString(), ()=>{})
//     next();
// }

// router.get('/user/:id', logOriginalUrl, (req, res, next)=>{
//     res.send("I will send user information #2. Id is even");
// })

//4
router.use(function(err, req, res, next){
    res.status(500).json({"err": err, "message":"Wrong of course!", "custom": err.status})
})

module.exports = router;