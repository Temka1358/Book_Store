const express = require("express");
const req = require("express/lib/request");
const { get } = require("express/lib/response");
const fs = require('fs')

const app  = express()
let path  = "/Users/mstars_lab1_13/Desktop/express-project/EJS/views"
app.set("view engine", "ejs")
app.set("views", path);
app.set("view options", { layout: false});
const data = require("../data.json")

app.get('/quotes', (req, res)=>{
    res.render('quotes', {quotes : data.quotes})
})

app.get("/quote/:id", (req, res)=>{
    res.render('quote', {quote: data.quotes[req.params.id]})
})

app.get("/", (req, res)=>{
    if(false){
        res.redirect("/quotes")
    }else{
         res.render("index", {name :"Temuulen"})
    }
})

app.get("*", function(req, res){
    res.render('404', {message: "message from index.js"})
})

module.exports = app;