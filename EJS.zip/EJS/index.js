
const express = require("express");
const req = require("express/lib/request");
const { get } = require("express/lib/response");
const apiRoutes = require("./routes/api.js")
const adminRoutes =require("./routes/admin.js")


const app  = express()
const port = 3000;
app.use(express.static("public"))
app.use(express.json())

let path  = "/Users/mstars_lab1_13/Desktop/express-project/EJS/views"
app.set("views", path);

app.use('/api', apiRoutes)
app.use("/", adminRoutes)



app.listen(port, ()=>{
    console.log("App is running at port 3000")
})